Untuk assignment kali ini, saya menggunakan node_socket.py yang ada pada assignment 1.

Maka, saya mengumpulkan juga program tersebut dalam zip